import { useEffect, useMemo, useState } from "react";
import { Navigate, useNavigate } from "react-router-dom";
import { useTranslation } from "react-i18next";
import { CalendarDays, LayoutGrid, LogOut, User } from "lucide-react";

import AppLoading from "@/components/app-loading";
import ThemeBackground from "@/components/theme-background";
import { useAuth } from "@/hooks/use-auth";
import { useProfile } from "@/hooks/use-profile";
import { useRecords } from "@/hooks/use-records";
import { useTheme } from "@/hooks/use-theme";
import { buildTypeColorMap, collectShootTypes, loadCustomTypes, saveCustomTypes } from "@/lib/shoot-types";
import type { CosplayRecord, CosplayRecordInput } from "@/lib/record-types";

import CalendarView from "./components/calendar-view";
import ExportRecordsButton from "./components/export-records-button";
import FilterBar from "./components/filter-bar";
import RecordsHeader from "./components/header";
import PhotoWallView from "./components/photo-wall-view";
import RecordDetail from "./components/record-detail";
import RecordForm from "./components/record-form";
import StatsSummary from "./components/stats-summary";
import YearInReview from "./components/year-in-review";
import { createDefaultFilter, useFilteredRecords } from "./use-record-filters";

type View = "calendar" | "wall";

export default function RecordsPage() {
  const { t } = useTranslation();
  const navigate = useNavigate();
  const { user, signOut } = useAuth();
  const { themeKey, setThemeKey, theme } = useTheme();
  const { displayName } = useProfile(user?.id);

  const { records, isLoading, addRecord, updateRecord, deleteRecord } = useRecords(user?.id);

  const [view, setView] = useState<View>("calendar");
  const [filter, setFilter] = useState(createDefaultFilter);
  const [search, setSearch] = useState("");
  const [display, setDisplay] = useState(() => {
    const now = new Date();
    return { year: now.getFullYear(), month: now.getMonth() };
  });
  const [formOpen, setFormOpen] = useState(false);
  const [editing, setEditing] = useState<CosplayRecord | null>(null);
  const [detail, setDetail] = useState<CosplayRecord | null>(null);
  const [customTypes, setCustomTypes] = useState<string[]>(loadCustomTypes);
  const [isNarrow, setIsNarrow] = useState(() => typeof window !== "undefined" && window.innerWidth < 640);
  const [reviewOpen, setReviewOpen] = useState(false);

  const filtered = useFilteredRecords(records, filter, search);

  const shootTypes = useMemo(() => collectShootTypes(records, customTypes), [records, customTypes]);
  const typeColorMap = useMemo(
    () => buildTypeColorMap(shootTypes, theme.typeColors),
    [shootTypes, theme.typeColors],
  );

  // 手機寬度偵測（手機上月曆檢視單獨呈現）
  useEffect(() => {
    function onResize() {
      setIsNarrow(window.innerWidth < 640);
    }

    window.addEventListener("resize", onResize);
    return () => window.removeEventListener("resize", onResize);
  }, []);

  // 12/31 當天自動打開年度回憶（同一年只自動彈一次）
  useEffect(() => {
    if (isLoading) return;

    const today = new Date();
    if (today.getMonth() !== 11 || today.getDate() !== 31) return;

    const year = today.getFullYear();
    if (!records.some((record) => record.date.slice(0, 4) === String(year))) return;

    const seenKey = `stir-diary:review-seen:${year}`;

    try {
      if (localStorage.getItem(seenKey)) return;
      localStorage.setItem(seenKey, "1");
    } catch {
      /* 忽略讀寫失敗 */
    }

    setReviewOpen(true);
  }, [isLoading, records]);

  // 篩選改變時，月曆跟著跳到對應的月份
  useEffect(() => {
    if (filter.mode === "month") {
      setDisplay({ year: filter.year, month: filter.month });
      return;
    }
    if (filter.mode === "year") {
      setDisplay({ year: filter.year, month: 0 });
      return;
    }
    if (filter.mode === "day" && filter.day) {
      const [year, month] = filter.day.split("-").map(Number);
      setDisplay({ year, month: month - 1 });
      return;
    }
    if (filter.mode === "range" && filter.start) {
      const [year, month] = filter.start.split("-").map(Number);
      setDisplay({ year, month: month - 1 });
    }
  }, [filter]);

  // 月曆要特別標示的日期
  const highlightSet = useMemo(() => {
    if (filter.mode === "day" && filter.day) {
      return new Set([filter.day]);
    }
    if (filter.mode === "range" && (filter.start || filter.end)) {
      return new Set(filtered.map((record) => record.date));
    }
    return null;
  }, [filter, filtered]);

  // 年度回憶預設打開的年份：今年有紀錄就用今年，否則用最近有紀錄的那一年
  const reviewStartYear = useMemo(() => {
    const currentYear = new Date().getFullYear();

    if (records.some((record) => record.date.slice(0, 4) === String(currentYear))) {
      return currentYear;
    }

    const years = records
      .map((record) => Number(record.date.slice(0, 4)))
      .filter((year) => Number.isFinite(year) && year > 0)
      .sort((a, b) => b - a);

    return years.length ? years[0] : currentYear;
  }, [records]);

  const activeMonth = filter.mode === "month" ? filter.month : null;

  // 只要做了篩選或搜尋，就自動切到照片牆
  function handleFilter(next: typeof filter) {
    setFilter(next);
    setView("wall");
  }

  function handleSearch(term: string) {
    setSearch(term);
    if (term.trim()) setView("wall");
  }

  function applySearch(term: string) {
    setSearch(term);
    setView("wall");
  }

  function handleClear() {
    setFilter(createDefaultFilter());
    setSearch("");
    setView("calendar");
  }

  function onPickMonth(month: number) {
    handleFilter({ ...createDefaultFilter(), mode: "month", year: filter.year, month });
  }

  function onTagClick(tag: string) {
    setDetail(null);
    applySearch(tag);
  }

  function addShootType(type: string) {
    setCustomTypes((current) => {
      if (current.includes(type) || shootTypes.includes(type)) return current;
      const next = [...current, type];
      saveCustomTypes(next);
      return next;
    });
  }

  async function handleSubmit(input: CosplayRecordInput) {
    if (editing) {
      await updateRecord(editing.id, input);
    } else {
      await addRecord(input);
    }
  }

  async function handleLogout() {
    try {
      await signOut();
      navigate("/login", { replace: true });
    } catch (error) {
      console.error("登出失敗：", error);
    }
  }

  if (!user) {
    return <Navigate to="/login" replace />;
  }

  if (isLoading) {
    return (
      <div className="relative min-h-screen">
        <ThemeBackground themeKey={themeKey} />
        <AppLoading label={t("auth.loading")} />
      </div>
    );
  }

  // 詳情視窗永遠顯示清單中的最新版本
  const detailLive = detail ? records.find((record) => record.id === detail.id) ?? null : null;

  // 右上角顯示註冊時填的暱稱（讀不到時退回帳號資料）
  const accountName =
    displayName ??
    (typeof user.user_metadata?.display_name === "string" ? user.user_metadata.display_name : null) ??
    user.email ??
    t("common.user");

  function ViewToggle() {
    const options: { key: View; icon: typeof CalendarDays; label: string }[] = [
      { key: "calendar", icon: CalendarDays, label: t("records.view.calendar") },
      { key: "wall", icon: LayoutGrid, label: t("records.view.wall") },
    ];

    return (
      <div className="flex rounded-full p-0.5" style={{ background: "var(--accent-soft)" }}>
        {options.map(({ key, icon: Icon, label }) => {
          const active = view === key;
          return (
            <button
              key={key}
              type="button"
              onClick={() => setView(key)}
              className="font-serif-tc flex items-center gap-1.5 rounded-full px-4 py-2 text-sm font-medium transition-colors"
              style={active ? { background: "var(--accent)", color: "var(--on-accent)" } : { color: "var(--text)" }}
            >
              <Icon size={16} />
              {label}
            </button>
          );
        })}
      </div>
    );
  }

  return (
    <div className="min-h-screen">
      <ThemeBackground themeKey={themeKey} />

      <RecordsHeader
        themeKey={themeKey}
        onThemeChange={setThemeKey}
        onAddRecord={() => {
          setEditing(null);
          setFormOpen(true);
        }}
        onOpenReview={() => setReviewOpen(true)}
      />

      {/* 登入者資訊列 */}
      <div className="mx-auto max-w-6xl px-4 pt-3 sm:px-6">
        <div className="flex flex-wrap items-center justify-end gap-3">
          <div className="flex items-center gap-2 text-sm" style={{ color: "var(--text)" }}>
            <User size={15} />
            <span className="max-w-[220px] truncate" title={accountName}>
              {accountName}
            </span>
          </div>

          <ExportRecordsButton
            records={records}
            account={{ id: user.id, email: user.email ?? "", displayName: accountName }}
          />

          <button
            type="button"
            onClick={handleLogout}
            className="font-serif-tc flex items-center gap-1.5 rounded-full px-3 py-1.5 text-sm transition-opacity hover:opacity-70"
            style={{ background: "var(--accent-soft)", color: "var(--text)" }}
          >
            <LogOut size={15} />
            {t("common.logout")}
          </button>
        </div>
      </div>

      <main className="mx-auto max-w-6xl space-y-5 px-4 py-4 sm:px-6 sm:py-6">
        {isNarrow && view === "calendar" ? (
          <>
            <CalendarView
              records={filtered}
              displayYear={display.year}
              displayMonth={display.month}
              onMonthChange={(year, month) => setDisplay({ year, month })}
              highlightSet={highlightSet}
              onRecordClick={setDetail}
              typeColorMap={typeColorMap}
            />

            <div className="flex justify-center">
              <ViewToggle />
            </div>
          </>
        ) : (
          <>
            <div className="flex flex-wrap items-center justify-between gap-3">
              <div>
                <h2 className="font-serif-tc text-xl font-bold" style={{ color: "var(--text)" }}>
                  {t("records.annualLog", { year: filter.year })}
                </h2>
                <p className="font-deco text-muted-foreground mt-0.5 text-[10px] tracking-[0.25em]">
                  {t("records.annualLogDeco", { year: filter.year })}
                </p>
              </div>

              <ViewToggle />
            </div>

            <StatsSummary records={filtered} typeColorMap={typeColorMap} onApplySearch={applySearch} />

            <FilterBar
              records={records}
              filter={filter}
              setFilter={handleFilter}
              count={filtered.length}
              search={search}
              setSearch={handleSearch}
              onClear={handleClear}
            />

            {view === "calendar" ? (
              <CalendarView
                records={filtered}
                displayYear={display.year}
                displayMonth={display.month}
                onMonthChange={(year, month) => setDisplay({ year, month })}
                highlightSet={highlightSet}
                onRecordClick={setDetail}
                typeColorMap={typeColorMap}
              />
            ) : (
              <PhotoWallView
                records={filtered}
                activeMonth={activeMonth}
                onPickMonth={onPickMonth}
                onRecordClick={setDetail}
                onAddRecord={() => { setEditing(null); setFormOpen(true); }}
                typeColorMap={typeColorMap}
              />
            )}
          </>
        )}

        <footer className="pt-6 pb-safe text-center">
          <p className="font-deco text-muted-foreground text-[10px] tracking-[0.3em]">{t("records.footer")}</p>
        </footer>
      </main>

      <RecordForm
        open={formOpen}
        editing={editing}
        userId={user.id}
        shootTypes={shootTypes}
        typeColorMap={typeColorMap}
        onAddShootType={addShootType}
        onSubmit={handleSubmit}
        onClose={() => setFormOpen(false)}
      />

      <RecordDetail
        record={detailLive}
        typeColorMap={typeColorMap}
        onDelete={deleteRecord}
        onEdit={(record) => {
          setDetail(null);
          setEditing(record);
          setFormOpen(true);
        }}
        onTagClick={onTagClick}
        onClose={() => setDetail(null)}
      />

      {reviewOpen && (
        <YearInReview
          records={records}
          startYear={reviewStartYear}
          typeColorMap={typeColorMap}
          onClose={() => setReviewOpen(false)}
        />
      )}
    </div>
  );
}
